GHEORGHE LUMINITA-GABRIELA, 312 CB
TEMA 2

CERINTA 0 - INTERACTIVE CONSOLE

  Interactive console a fost implementata in functia main. La inceputul functiei au fost declarata variabila 'poem' in care va fi stocata poezia, si variabila 'path' ce va contine calea catre fisierul in care se gaseste poezia. Ambele variabile au fost alocate dinamic cu ajutorul functiei 'malloc' din biblioteca <stdlib.h>, prezenta in antetul programului.
  Pentru a putea introduce comenzi una dupa alta de la tastatura fara a se intrerupe programul, am folosit instructiunea repetitiva while.
  Comanda introdusa de la tastatura va fi citita cu fgets, care va citi la final si un '\n' pe care l-am eliminat ulterior.
  Dupa introducerea comenzii, aceasta va fi comparata cu anumite cuvinte cheie folosind functia 'strcmp' din biblioteca <string.h> si se va intra pe diferite cazuri.
  Astfel, daca de la stdin se introduce comanda 'uppercase', se va intra pe primul caz, daca se introduce comanda 'trimming' se va intra pe cel de-al doilea caz. Comanda 'make+it_silly' va genera al treilea caz, 'make_it_friendly' va reprezenta cel de-al patrulea caz si 'make_it_rhyme' cel de-al cincilea caz. 
  Totodata ca si comenzi de la stdin sunt si 'print' si 'quit'. Comanda 'Print va afisa la standard output poezia prelucrata pana in acel moment, depinzand de comenzile ce au fost introduse, pe cand comanda 'quit' are rolul de a intrerupe introducerea succesiunii de comenzi si iesirea din bucla while.
  Orice implementare a programului va incepe cu comanda 'load' urmata de calea catre fisierul unde este salvata poezia. La introducerea acestei comenzi, se va salva in variabila 'path'(cu functia <strcpy>) calea catre locul unde se afla poezia, iar la apelul functiei 'load_file' se va salva in variabila 'poem' poezia pe care urmeaza sa o modificam prin viitoarele comenzi introduse. Funcita load_file se afla in biblioteca 'helper' ce este declarata in antetul programului.

CERINTA 1 - UPPERCASE

  La introducerea comenzii 'uppercase' se va apela functia uppercase care nu va returna nimic, fiind de tipul void si care va primi drpt parametru un ponter de tip char, si anume variabila poem. Se parcurg toate caracterele poeziei cu ajutorul unui for, iar la intalnirea unei majuscule, aceasta va fi transfomata in litera minuscula cu ajutorul codului ASCII. Daca un caracter se afla intre 64 si 91, conform codului ASCII, aceasta este o litera mare(A-Z) si prin adunarea numarului 32(diferenta dintre o litera mare si una mica) se va transforma in litera minuscula. In acest moment, toate literele poeziei vor fi minuscule.
  Se parcurge din nou poezia, si se pune conditia ca la intalnirea caracterului '\n', ce reprezinta trecerea la un nou rand, si verificarea daca litera ce il precede este una majuscula(este mai mare sau egala decat 97 si mai mica sau egala decat 122), aceasta litera sa se transforme intr-una minuscula prin scaderea lui 32 din litera respectiva. Astfel, prima litera de la inceputul fiecarui vers va fi majuscula, inafara de cea de la inceputul poeziei care se va converti separat(ea nu este precedata de un '\n'.


CERINTA 2 - TRIMMING

  
  La introducerea comenzii 'trimming' se va apela functia trimming de tipul void, ce primeste ca parametru un pointer de tipul char, si anume poezia salvata in variabila 'poem'. 
  In prima parte a functiei se elimina spatiile in plus. Pentru aceasta, se parcurg caracterele poeziei intr-un for, iar atunci cand se intalneste un caracter diferit de spatiu, se va stoca tot in sirul poem, cu indentarea incepand de la zero. 
  La intalnirea unui spatiu, se introduce o noua variabila, j, ce reprezinta pozitia urmatoare fata de pozitia in care a fost gasit spatiul. Atata timpp cat spatiul gasit este precedat si de alte spatii, variabila j creste cu o unitate.
  Se sare apoi peste spatiile in plus, egaland variabila i(pozitia primului spatiu, cu variabila j, pozitia primei litere de dupa insiruierea de spatii.
  Se lasa apoi doar primul spatiu intalnit, celelalte fiind completatea de caracterele diferite de spatiu, in ordinea in care apar in poem.
 In final, dupa construirea poemului fara spatii in plus, se pune delimitatorul de siruri pentru a sterge dublurile caracterelor din finalul sirului.

  In a doua parte a functiei se elimina delimitatorii. Pentru aceasta, se iau doua variabile, a si b care pornesc de la zero. Se parcurge poezia caracter cu caracter, iar daca acel caracter nu este unul din lista de delimitatori, se va stoca in noul vector creat indentat de la b = 0 ce este format numai din litere.

CERINTA 3 - MAKE IT SILLY

  La introducerea comenzii 'make_it_silly prob', se va intra pe un caz construit in functia 'main'. Este declarata o variabiala pointer de tip char 'prob', ce reprezinta probabilitatea introdusa de la tastatura, careia ii alocam dinamic memorie. Cu functia strcpy, in variabila prob stocam probabilitatea prin extragerea din comanda a ultimelor date introduse. Aceste date sunt de tip char initial, si pentru a le transforma in niste variabile de tip float, se face conversia cu ajutorul functiei atof. Se apeleaza apoi functia 'make-it_silly' ce primeste ca parametru variabiala poem, in care este stocata poezia si variabila 'val_float' ce este probabilitatea.
  In functia make_it_silly este declarata variabila de tip float sample, care va genera in mod aleatoriu o valoare intre 0 si 1. Se parcurge poemul, iar la intalnirea unei litere mari(mai mare sau egala decat 65 si mai mica sau egala decat 90 in codul ASCII), se genereaza numarul random. Daca acesta este mai mic decat probabilitatea introdusa de la tastatura, litera se va transforma in majuscula. Altfel, daca litera este majuscula(mai mare sau egala decat 97 si mai mica sau egala decat 122), se va transforma in minuscula.

CERINTA 4 - MAKE IT FRIENDLIER 

  La introducerea comenzii 'make_it_friendlier', se va apela functia friendly ce returneaza un pointer de tipul char si primeste ca parametru tot un pointer de tipul char, si anume variabila poem. In functia 'friendly' se lucreaza pe o copie a poeziei, si cu functia strtok se desparte poezia in cuvinte, separatorii cuvintelor fiind declarati in antetul programului prin: #define SEPARATORS " .,:;!?\n". In vectorul words[MAX], se vor stoca cuvintele ce alcatuiesc poezia si se apeleaza functia 'get_friendly_word' din biblioteca helper ce returneaza in variabila 'friendly' diminutivele cuvintelor din vectorul 'words', in cazul in care acestea exista, si NULL in cazul in care nu exista diminutiv pentru un anumit cuvant.
  Daca variabila friendly este diferita de NULL, adica s-a gasit un diminutiv pentru un anumit cuvant din vectorul 'words', se va apela functia replacing ce primeste ca parametru variabila poem, cuvantul de inlocuit, si anume vectorul 'word', si cuvantul cu care trebuie inlocuit word[i], si anume *friendly.

-functionarea functiei replacing
  Se parcurg caracterele din variabila poem, si, cu functia 'strstr' din biblioteca <string.h> se verifica pe rand daca cuvintele stocate in vectorul words se gasesc in poezie. La gasirea acestor cuvinte, se verifica daca nu au fost deja inlocuite cu diminutivul lor(cazul in care un poem contine de mai multe ori un acelasi cuvant ce are diminutiv). In cazul in care au fost deja inlocuite, se face din nou replacing cu acelasi diminutiv(nu se observa nicio schimbare), aceasta comanda fiind necesara pentru a nu forma diminutivul diminutivului unui cuvant:
	-  de exemplu, poemul din testul 5 contine de doua ori cuvantul 'om'. La prima aparitie a acestuia, este schimbat in 'omusorusor' pentru ca, atunci cand programul incearca se faca diminutivul celui de-al doilea cuvant, il va gasi si pe primul, 'omusor', ce continue cuvantul 'om' in interiorul sau, si va mai aplica o data diminutivul pe el.
  Poem acum va indica dupa cuvantul ce avusese diminutiv, iar variabila i in acelasi loc.
  In cazul in care un cuvant nu a fost deja inlocuit cu al sau diminutiv, cu functia 'strcpy' se face replacing in variabila result[i] ce va indica spre prima litera a cuvantului ce va fi schimbat, cu diminutivul sau, i-ul punctand dupa diminutivul nou-creat, iar poem indicand pozitia de dupa cuvantul ce a fost schimbat.
  In cazul in care un cuvant nu trebuie modificat, variabila result va fi urmatoarea litera de analizat, iar variabila poem va indica pozitia urmatorului caracter.
